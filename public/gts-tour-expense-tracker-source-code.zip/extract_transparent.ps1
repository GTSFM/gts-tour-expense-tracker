Add-Type -AssemblyName System.Drawing

$src = [System.Drawing.Bitmap]::FromFile((Resolve-Path "public/logo.jpg").Path)
$w = $src.Width
$h = $src.Height

$out = New-Object System.Drawing.Bitmap($w, $h, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)

# Background reference
$bgR = 61.0
$bgG = 43.0
$bgB = 155.0

for ($x = 0; $x -lt $w; $x++) {
    for ($y = 0; $y -lt $h; $y++) {
        $p = $src.GetPixel($x, $y)
        
        # Distance from background color
        $dist = [Math]::Sqrt([Math]::Pow($p.R - $bgR, 2) + [Math]::Pow($p.G - $bgG, 2) + [Math]::Pow($p.B - $bgB, 2))
        
        # Luminance
        $lum = ($p.R * 0.299 + $p.G * 0.587 + $p.B * 0.114)
        
        # If it's near background or at image boundary artifact (x==0, x==w-1, etc.)
        if ($dist -lt 35 -or $x -le 1 -or $x -ge $w - 2 -or $y -le 1 -or $y -ge $h - 2) {
            # Completely transparent
            $out.SetPixel($x, $y, [System.Drawing.Color]::FromArgb(0, 255, 255, 255))
        } else {
            # Smooth alpha based on luminance / distance
            # Minimum alpha threshold for anti-aliasing
            $alpha = [Math]::Min(255, [Math]::Max(0, [int](($lum - 85.0) / (255.0 - 85.0) * 255.0)))
            if ($alpha -lt 15) {
                $out.SetPixel($x, $y, [System.Drawing.Color]::FromArgb(0, 255, 255, 255))
            } else {
                # Pure crisp white with calculated alpha
                $out.SetPixel($x, $y, [System.Drawing.Color]::FromArgb($alpha, 255, 255, 255))
            }
        }
    }
}

$out.Save("public/logo-transparent.png", [System.Drawing.Imaging.ImageFormat]::Png)
Write-Output "Saved public/logo-transparent.png"

$src.Dispose()
$out.Dispose()
