Add-Type -AssemblyName System.Drawing

$logoPath = Resolve-Path "public/logo.jpg"
$srcImg = [System.Drawing.Bitmap]::FromFile($logoPath.Path)

$sampleColor = $srcImg.GetPixel(5, 5)
Write-Output "Sampled Logo Color at (5,5): R=$($sampleColor.R), G=$($sampleColor.G), B=$($sampleColor.B)"

# Also let's check corner pixels and edge pixels
$cTopLeft = $srcImg.GetPixel(0, 0)
$cTopRight = $srcImg.GetPixel($srcImg.Width - 1, 0)
$cBotLeft = $srcImg.GetPixel(0, $srcImg.Height - 1)
$cBotRight = $srcImg.GetPixel($srcImg.Width - 1, $srcImg.Height - 1)
Write-Output "TopLeft: R=$($cTopLeft.R), G=$($cTopLeft.G), B=$($cTopLeft.B)"
Write-Output "TopRight: R=$($cTopRight.R), G=$($cTopRight.G), B=$($cTopRight.B)"
Write-Output "BotLeft: R=$($cBotLeft.R), G=$($cBotLeft.G), B=$($cBotLeft.B)"
Write-Output "BotRight: R=$($cBotRight.R), G=$($cBotRight.G), B=$($cBotRight.B)"

$srcImg.Dispose()
