Add-Type -AssemblyName System.Drawing

$logoPath = Resolve-Path "public/logo.jpg"
Write-Output "Loading logo from $logoPath"

$srcImg = [System.Drawing.Image]::FromFile($logoPath)
Write-Output "Source image width: $($srcImg.Width), height: $($srcImg.Height)"

# Function to create an app icon
function Create-AppIcon {
    param (
        [int]$CanvasSize,
        [string]$OutputPath,
        [double]$PaddingRatio = 0.18 # 18% padding keeps within Android maskable safe zone (80% circle)
    )

    $targetBmp = New-Object System.Drawing.Bitmap($CanvasSize, $CanvasSize, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($targetBmp)
    
    # High-quality rendering settings
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality

    # Background color: GTS Corporate Purple
    # Let's sample the background color from top-left pixel of srcImg or use #432488
    $bgColor = [System.Drawing.Color]::FromArgb(255, 67, 36, 136) # #432488
    $brush = New-Object System.Drawing.SolidBrush($bgColor)
    $g.FillRectangle($brush, 0, 0, $CanvasSize, $CanvasSize)

    # Compute target dimensions preserving aspect ratio inside safe area
    $safeWidth = $CanvasSize * (1.0 - ($PaddingRatio * 2.0))
    $safeHeight = $CanvasSize * (1.0 - ($PaddingRatio * 2.0))

    $scale = [Math]::Min($safeWidth / $srcImg.Width, $safeHeight / $srcImg.Height)
    $destWidth = [int]($srcImg.Width * $scale)
    $destHeight = [int]($srcImg.Height * $scale)

    $destX = [int](($CanvasSize - $destWidth) / 2)
    $destY = [int](($CanvasSize - $destHeight) / 2)

    # Draw the source image
    $destRect = New-Object System.Drawing.Rectangle($destX, $destY, $destWidth, $destHeight)
    $g.DrawImage($srcImg, $destRect, 0, 0, $srcImg.Width, $srcImg.Height, [System.Drawing.GraphicsUnit]::Pixel)

    # Save as high-res PNG
    $targetBmp.Save($OutputPath, [System.Drawing.Imaging.ImageFormat]::Png)

    $g.Dispose()
    $brush.Dispose()
    $targetBmp.Dispose()
    Write-Output "Created: $OutputPath ($CanvasSize x $CanvasSize)"
}

Create-AppIcon -CanvasSize 512 -OutputPath "public/icon-512.png" -PaddingRatio 0.16
Create-AppIcon -CanvasSize 512 -OutputPath "public/icon-maskable-512.png" -PaddingRatio 0.22
Create-AppIcon -CanvasSize 192 -OutputPath "public/icon-192.png" -PaddingRatio 0.16
Create-AppIcon -CanvasSize 180 -OutputPath "public/apple-touch-icon.png" -PaddingRatio 0.14
Create-AppIcon -CanvasSize 64 -OutputPath "public/favicon-64.png" -PaddingRatio 0.12
Create-AppIcon -CanvasSize 32 -OutputPath "public/favicon-32.png" -PaddingRatio 0.10

# Also copy to dist
Copy-Item "public/icon-512.png" "dist/icon-512.png" -Force
Copy-Item "public/icon-maskable-512.png" "dist/icon-maskable-512.png" -Force
Copy-Item "public/icon-192.png" "dist/icon-192.png" -Force
Copy-Item "public/apple-touch-icon.png" "dist/apple-touch-icon.png" -Force
Copy-Item "public/favicon-64.png" "dist/favicon-64.png" -Force
Copy-Item "public/favicon-32.png" "dist/favicon-32.png" -Force

$srcImg.Dispose()
Write-Output "All icons generated successfully!"
