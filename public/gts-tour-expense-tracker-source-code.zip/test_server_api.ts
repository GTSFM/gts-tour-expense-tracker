import http from 'http';

console.log('Testing Server API Endpoints...');

async function run() {
  // Let's spawn or start the server via node in background and verify
  const res = await fetch('http://localhost:5001/api/users').catch(() => null);
  console.log('Server is running?', res ? 'YES' : 'NO');
}

run();
