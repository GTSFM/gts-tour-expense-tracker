$exclude = @('node_modules', '.git', '*.zip', '*.log', 'test_*.ts', 'pack.ps1')
$items = Get-ChildItem -Path . | Where-Object { 
    $name = $_.Name
    $skip = $false
    foreach ($pat in $exclude) {
        if ($name -like $pat) { $skip = $true; break }
    }
    -not $skip
} | Select-Object -ExpandProperty FullName

$tempZip = Join-Path (Get-Location) 'temp_portable.zip'
if (Test-Path $tempZip) { Remove-Item $tempZip -Force }

Compress-Archive -Path $items -DestinationPath $tempZip -Force

Copy-Item $tempZip 'dist\gts-tour-expense-tracker-portable.zip' -Force
Copy-Item $tempZip 'public\gts-tour-expense-tracker-portable.zip' -Force
Remove-Item $tempZip -Force

$len = (Get-Item 'dist\gts-tour-expense-tracker-portable.zip').Length / 1MB
Write-Host "Success! Created portable zip ($([Math]::Round($len, 2)) MB)"
