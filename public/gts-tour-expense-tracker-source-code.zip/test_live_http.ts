console.log('Testing live API on http://localhost:5050 ...');

async function testLiveAPI() {
  const BASE = 'http://localhost:5050';

  // 1. Check UI index.html
  const uiRes = await fetch(`${BASE}/`);
  console.log('1. UI root returned status:', uiRes.status, 'HTML length:', (await uiRes.text()).length);

  // 2. Check /api/users
  const usersRes = await fetch(`${BASE}/api/users`);
  const usersData = await usersRes.json();
  console.log('2. Users count:', usersData.users?.length);

  // 3. Check /api/policies
  const polRes = await fetch(`${BASE}/api/policies`);
  const polData = await polRes.json();
  console.log('3. Policies count:', polData.policies?.length, 'B1 Hotel Cap:', polData.policies?.[0]?.hotelMaxPerNight);

  // 4. Check /api/claims
  const claimsRes = await fetch(`${BASE}/api/claims`, {
    headers: { 'x-user-id': 'u-president' }
  });
  const claimsData = await claimsRes.json();
  console.log('4. Claims count for President:', claimsData.claims?.length);

  // 5. Check dashboard stats
  const statsRes = await fetch(`${BASE}/api/reports/dashboard-stats`, {
    headers: { 'x-user-id': 'u-admin' }
  });
  const statsData = await statsRes.json();
  console.log('5. Company Spend:', statsData.metrics?.financials?.totalGross, 'Total Employees:', statsData.metrics?.totalEmployees);

  console.log('ALL LIVE ENDPOINT PROBES SUCCESSFUL!');
}

testLiveAPI().catch(console.error);
