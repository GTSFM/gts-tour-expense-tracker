async function runVerification() {
  const BASE = 'http://127.0.0.1:5050';
  console.log('--- STARTING VERIFICATION OF BACKOFFICE, MULTI-USER OPS & REGISTRATION ---');

  // Test 1: Operations Executive / Manager login by name
  let res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'Operations Executive / Manager', password: 'GTSOPS@123' })
  });
  let data = await res.json();
  console.log('1. Ops Exec Login by Name:', res.status, data.user?.name, 'Role:', data.user?.role, 'Band:', data.user?.band);
  if (!res.ok) throw new Error('Ops Exec Login failed: ' + JSON.stringify(data));

  // Test 2: Another Operations Employee login (Ramesh Babu, GTS002)
  res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'Ramesh Babu', password: 'GTSOPS@123' })
  });
  data = await res.json();
  console.log('2. Ramesh Babu Login by Name:', res.status, data.user?.name, 'ID:', data.user?.employeeId, 'Designation:', data.user?.designation);
  if (!res.ok) throw new Error('Ramesh Babu login failed');

  // Test 3: Backoffice HR login (Priya Sharma, GTS-BO-01)
  res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'Priya Sharma', password: 'GTSBO@123' })
  });
  data = await res.json();
  console.log('3. Backoffice HR Login:', res.status, data.user?.name, 'Dept:', data.user?.department, 'Designation:', data.user?.designation, 'Band:', data.user?.band);
  if (!res.ok) throw new Error('Priya Sharma HR login failed');

  // Test 4: Backoffice Senior Manager Admin (Ramesh Kumar, GTS-BO-05) -> Band B2
  res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'GTS-BO-05', password: 'GTSBO@123' })
  });
  data = await res.json();
  console.log('4. Backoffice Senior Manager Admin Login by ID:', res.status, data.user?.name, 'Band:', data.user?.band);
  if (!res.ok || data.user?.band !== 'B2') throw new Error('Senior Manager Admin band verification failed');

  // Test 5: Backoffice GM Backend process (Rajesh Kannan, GTS-BO-09) -> Band B3
  res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'Rajesh Kannan', password: 'GTSBO@123' })
  });
  data = await res.json();
  console.log('5. Backoffice GM Backend Process Login:', res.status, data.user?.name, 'Band:', data.user?.band);
  if (!res.ok || data.user?.band !== 'B3') throw new Error('GM Backend process band verification failed');

  // Test 6: Registration with Name & Custom Password
  const testRegPayload = {
    name: 'Vikas Swaminathan',
    employeeId: 'GTS-BO-99',
    designation: 'Manager Admin',
    band: 'B1',
    department: 'Backoffice function',
    region: 'Tamil Nadu',
    location: 'Chennai HQ',
    mobile: '9840199999',
    email: 'vikas.swaminathan@gtsfacilities.com',
    reportingManager: 'Venkatesh R',
    approvingAuthorityId: 'reg-02',
    approvingAuthorityName: 'Yoganandam',
    password: 'MySecretPassword@999'
  };

  res = await fetch(`${BASE}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(testRegPayload)
  });
  data = await res.json();
  console.log('6. Register new Backoffice Employee:', res.status, data.user?.name, 'ID:', data.user?.employeeId, 'Status:', data.user?.status);
  if (!res.ok) throw new Error('Registration failed: ' + JSON.stringify(data));

  // Test 7: Login immediately using newly registered employee Name & Custom Password
  res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'Vikas Swaminathan', password: 'MySecretPassword@999' })
  });
  data = await res.json();
  console.log('7. Newly Registered User Login by Name:', res.status, data.user?.name, 'Email:', data.user?.email);
  if (!res.ok) throw new Error('Newly registered user login failed');

  // Test 8: Verify Directors have no Band
  res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'Mariappan S', password: 'Mariappan@123' })
  });
  data = await res.json();
  console.log('8. Director Mariappan S Login:', res.status, data.user?.name, 'Role:', data.user?.role, 'Band:', data.user?.band || '(none)');

  res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'PrabakarB', password: 'Prabakar@123' })
  });
  data = await res.json();
  console.log('8b. Director PrabakarB Login:', res.status, data.user?.name, 'Role:', data.user?.role, 'Band:', data.user?.band || '(none)');

  // Test 9: Master Admin Add Employee endpoint
  res = await fetch(`${BASE}/api/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Pooja Iyer',
      employeeId: 'GTS-BO-101',
      designation: 'Asst HR',
      band: 'B1',
      department: 'Backoffice function',
      region: 'Karnataka',
      location: 'Bangalore Office',
      mobile: '9840188888',
      email: 'pooja.iyer@gtsfacilities.com',
      reportingManager: 'Priya Sharma',
      approvingAuthorityId: 'reg-01',
      approvingAuthorityName: 'Samuel',
      password: 'Pooja@Password123'
    })
  });
  data = await res.json();
  console.log('9. Master Admin Create Employee Endpoint:', res.status, data.user?.name, 'ID:', data.user?.employeeId);
  if (!res.ok) throw new Error('Admin create user failed');

  // Test 10: Login with user created by Admin
  res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'Pooja Iyer', password: 'Pooja@Password123' })
  });
  data = await res.json();
  console.log('10. Admin-Created User Login by Name:', res.status, data.user?.name, 'Status:', data.user?.status);
  if (!res.ok) throw new Error('Admin-created user login failed');

  console.log('\n>>> ALL 10 TESTS PASSED SUCCESSFULLY! <<<');
}

runVerification().catch(err => {
  console.error('TEST ERROR:', err);
  process.exit(1);
});
