Add-Type -AssemblyName System.Drawing

$bmp = [System.Drawing.Bitmap]::FromFile((Resolve-Path "public/logo.jpg").Path)

for ($x = 0; $x -lt 15; $x++) {
    $p = $bmp.GetPixel($x, 70)
    Write-Output "x=$($x) -> R=$($p.R), G=$($p.G), B=$($p.B)"
}
Write-Output "---"
for ($y = 0; $y -lt 15; $y++) {
    $p = $bmp.GetPixel(50, $y)
    Write-Output "y=$($y) -> R=$($p.R), G=$($p.G), B=$($p.B)"
}

$bmp.Dispose()
