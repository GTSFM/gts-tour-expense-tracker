Add-Type -AssemblyName System.Drawing

$bmp = [System.Drawing.Bitmap]::FromFile((Resolve-Path "public/logo.jpg").Path)
Write-Output "Size: $($bmp.Width) x $($bmp.Height)"

$minR = 255; $maxR = 0
$minG = 255; $maxG = 0
$minB = 255; $maxB = 0

# Sample the background in a 20x20 patch at (10,10)
for ($x = 5; $x -lt 25; $x++) {
    for ($y = 5; $y -lt 25; $y++) {
        $p = $bmp.GetPixel($x, $y)
        if ($p.R -lt $minR) { $minR = $p.R }
        if ($p.R -gt $maxR) { $maxR = $p.R }
        if ($p.G -lt $minG) { $minG = $p.G }
        if ($p.G -gt $maxG) { $maxG = $p.G }
        if ($p.B -lt $minB) { $minB = $p.B }
        if ($p.B -gt $maxB) { $maxB = $p.B }
    }
}

Write-Output "Background variance in (5..25, 5..25):"
Write-Output "R: $minR .. $maxR"
Write-Output "G: $minG .. $maxG"
Write-Output "B: $minB .. $maxB"

# Let's find white pixels
$whiteCount = 0
for ($x = 0; $x -lt $bmp.Width; $x++) {
    for ($y = 0; $y -lt $bmp.Height; $y++) {
        $p = $bmp.GetPixel($x, $y)
        if ($p.R -gt 200 -and $p.G -gt 200 -and $p.B -gt 200) {
            $whiteCount++
        }
    }
}
Write-Output "Total pixels: $($bmp.Width * $bmp.Height), White pixels (>200): $whiteCount"

$bmp.Dispose()
