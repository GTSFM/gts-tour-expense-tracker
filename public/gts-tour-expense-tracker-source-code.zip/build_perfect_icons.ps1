Add-Type -AssemblyName System.Drawing

$transparentLogoPath = (Resolve-Path "public/logo-transparent.png").Path
$transImg = [System.Drawing.Bitmap]::FromFile($transparentLogoPath)

# Trim transparent bounds to get tight bounding box of logo content
$minX = $transImg.Width; $maxX = 0
$minY = $transImg.Height; $maxY = 0

for ($x = 0; $x -lt $transImg.Width; $x++) {
    for ($y = 0; $y -lt $transImg.Height; $y++) {
        $p = $transImg.GetPixel($x, $y)
        if ($p.A -gt 20) {
            if ($x -lt $minX) { $minX = $x }
            if ($x -gt $maxX) { $maxX = $x }
            if ($y -lt $minY) { $minY = $y }
            if ($y -gt $maxY) { $maxY = $y }
        }
    }
}

$tightW = ($maxX - $minX) + 1
$tightH = ($maxY - $minY) + 1
Write-Output "Tight logo bounding box: ($minX, $minY) - $tightW x $tightH"

# Extract cropped tight transparent logo
$tightLogo = New-Object System.Drawing.Bitmap($tightW, $tightH, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$gTight = [System.Drawing.Graphics]::FromImage($tightLogo)
$gTight.DrawImage($transImg,
    (New-Object System.Drawing.Rectangle(0, 0, $tightW, $tightH)),
    $minX, $minY, $tightW, $tightH,
    [System.Drawing.GraphicsUnit]::Pixel)
$gTight.Dispose()
$transImg.Dispose()

$tightLogo.Save("public/logo-tight-white.png", [System.Drawing.Imaging.ImageFormat]::Png)

# Background color: authentic GTS purple from uploaded logo
$brandColor = [System.Drawing.Color]::FromArgb(255, 60, 42, 154) # #3C2A9A

function Make-PwaIcon {
    param(
        [int]$Size,
        [string]$Path,
        [double]$PaddingRatio = 0.16 # percentage of canvas on each side
    )

    $bmp = New-Object System.Drawing.Bitmap($Size, $Size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality

    # 1. Fill solid GTS royal corporate purple
    $brush = New-Object System.Drawing.SolidBrush($brandColor)
    $g.FillRectangle($brush, 0, 0, $Size, $Size)

    # 2. Compute fitting for tight logo
    $availW = $Size * (1.0 - ($PaddingRatio * 2.0))
    $availH = $Size * (1.0 - ($PaddingRatio * 2.0))

    $scale = [Math]::Min($availW / $tightW, $availH / $tightH)
    $destW = [int]($tightW * $scale)
    $destH = [int]($tightH * $scale)

    $destX = [int](($Size - $destW) / 2)
    $destY = [int](($Size - $destH) / 2)

    $destRect = New-Object System.Drawing.Rectangle($destX, $destY, $destW, $destH)
    $g.DrawImage($tightLogo, $destRect, 0, 0, $tightW, $tightH, [System.Drawing.GraphicsUnit]::Pixel)

    $bmp.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)

    $g.Dispose()
    $brush.Dispose()
    $bmp.Dispose()
    Write-Output "Generated perfect icon: $Path ($Size x $Size)"
}

# 1. Standard PWA 512x512
Make-PwaIcon -Size 512 -Path "public/icon-512.png" -PaddingRatio 0.15

# 2. Android Maskable 512x512 (Android safe-zone is central 80% circle, so padding >= 0.20 ensures no clipping by any launcher)
Make-PwaIcon -Size 512 -Path "public/icon-maskable-512.png" -PaddingRatio 0.22

# 3. Standard PWA 192x192
Make-PwaIcon -Size 192 -Path "public/icon-192.png" -PaddingRatio 0.15

# 4. Apple Touch Icon 180x180
Make-PwaIcon -Size 180 -Path "public/apple-touch-icon.png" -PaddingRatio 0.15

# 5. Favicons
Make-PwaIcon -Size 64 -Path "public/favicon-64.png" -PaddingRatio 0.10
Make-PwaIcon -Size 32 -Path "public/favicon-32.png" -PaddingRatio 0.08
Make-PwaIcon -Size 16 -Path "public/favicon-16.png" -PaddingRatio 0.06

# Also generate a crisp rectangular logo.png for header & modals with perfect clean solid background
$rectW = 320
$rectH = 160
$rectBmp = New-Object System.Drawing.Bitmap($rectW, $rectH, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$gRect = [System.Drawing.Graphics]::FromImage($rectBmp)
$gRect.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$gRect.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
$gRect.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
$gRect.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality

$brushRect = New-Object System.Drawing.SolidBrush($brandColor)
$gRect.FillRectangle($brushRect, 0, 0, $rectW, $rectH)

$scaleRect = [Math]::Min(($rectW * 0.88) / $tightW, ($rectH * 0.85) / $tightH)
$dw = [int]($tightW * $scaleRect)
$dh = [int]($tightH * $scaleRect)
$dx = [int](($rectW - $dw) / 2)
$dy = [int](($rectH - $dh) / 2)

$gRect.DrawImage($tightLogo, (New-Object System.Drawing.Rectangle($dx, $dy, $dw, $dh)), 0, 0, $tightW, $tightH, [System.Drawing.GraphicsUnit]::Pixel)
$rectBmp.Save("public/logo.png", [System.Drawing.Imaging.ImageFormat]::Png)
$rectBmp.Save("public/logo.jpg", [System.Drawing.Imaging.ImageFormat]::Jpeg)
$gRect.Dispose()
$brushRect.Dispose()
$rectBmp.Dispose()

$tightLogo.Dispose()

# Copy to dist
$filesToCopy = @(
    "icon-512.png",
    "icon-maskable-512.png",
    "icon-192.png",
    "apple-touch-icon.png",
    "favicon-64.png",
    "favicon-32.png",
    "favicon-16.png",
    "logo.png",
    "logo.jpg",
    "logo-transparent.png"
)

foreach ($f in $filesToCopy) {
    Copy-Item "public/$f" "dist/$f" -Force
}

Write-Output "All icons and logos regenerated and synchronized to public and dist!"
