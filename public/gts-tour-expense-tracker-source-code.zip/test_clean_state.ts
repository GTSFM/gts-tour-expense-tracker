async function verifyCleanStateAndOpenGeneration() {
  const BASE = 'http://127.0.0.1:5050';
  console.log('===========================================================');
  console.log('VERIFYING CLEAN SLATE: NO PRE-SEEDED DUMMIES & NO CLAIMS');
  console.log('===========================================================');

  // Test 1: Check Claims count is 0
  let res = await fetch(`${BASE}/api/claims`);
  let data = await res.json();
  console.log(`1. Total Claims in Database: ${data.claims?.length} (Expected: 0)`);
  if (data.claims?.length !== 0) throw new Error('Expected 0 claims, found: ' + data.claims?.length);

  // Test 2: Check Tours count is 0
  res = await fetch(`${BASE}/api/tours`);
  data = await res.json();
  console.log(`2. Total Tours in Database: ${data.tours?.length} (Expected: 0)`);
  if (data.tours?.length !== 0) throw new Error('Expected 0 tours, found: ' + data.tours?.length);

  // Test 3: Check Users count and verify no pre-seeded dummy employees exist
  res = await fetch(`${BASE}/api/users`);
  data = await res.json();
  const users = data.users || [];
  console.log(`3. Total Authorities & Governance Users: ${users.length} (Expected: 11)`);
  
  const dummyNames = ['Operations Executive / Manager', 'Ramesh Babu', 'Praveen Kumar', 'Suresh Raina', 'Priya Sharma', 'Ananya Rao', 'Karthik N', 'Venkatesh R', 'Ramesh Kumar', 'Lakshmi Narayanan', 'Srinivasan M', 'Deepak Verma', 'Rajesh Kannan', 'Sneha Reddy'];
  const foundDummies = users.filter((u: any) => dummyNames.includes(u.name) || u.employeeId === 'GTS001' || u.employeeId === 'GTS-BO-01');
  if (foundDummies.length > 0) {
    throw new Error('Found pre-seeded dummy users still in database: ' + JSON.stringify(foundDummies.map((u: any) => u.name)));
  }
  console.log('   ✓ Zero pre-seeded dummy employee names found. Clean slate confirmed!');

  // Test 4: Authority Logins
  const authorities = [
    { name: 'President', ident: 'Bharanidhar Tarimana', pw: 'Bharani@123' },
    { name: 'Director 1', ident: 'Mariappan S', pw: 'Mariappan@123' },
    { name: 'Director 2', ident: 'PrabakarB', pw: 'Prabakar@123' },
    { name: 'RH 01', ident: 'RH 01 - GTSPCH', pw: 'GTSPCH@01' },
    { name: 'RH 02', ident: 'RH 02 - GTSPCH', pw: 'GTSPCH@02' },
    { name: 'RH 03', ident: 'RH 03 - GTSPCH', pw: 'GTSPCH@03' },
    { name: 'RH 04', ident: 'RH 04 - GTSPCH', pw: 'GTSPCH@04' },
    { name: 'CRM', ident: 'CRM - Tejinder Singh', pw: 'CRM@123' },
    { name: 'Auditor', ident: 'Auditor', pw: 'Audit@123' },
    { name: 'Accounts', ident: 'Accounts', pw: 'Accounts@123' },
    { name: 'Master Admin', ident: 'admin@gts.com', pw: 'Admin@123' }
  ];

  for (const auth of authorities) {
    res = await fetch(`${BASE}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier: auth.ident, password: auth.pw })
    });
    data = await res.json();
    if (!res.ok) throw new Error(`Authority login failed for ${auth.name}: ${JSON.stringify(data)}`);
    console.log(`4. Authority Login [${auth.name}]: OK (User: ${data.user?.name})`);
  }

  // Test 5: Open Employee Generation
  console.log('\n--- TESTING OPEN NEW EMPLOYEE GENERATION & FULL WORKFLOW ---');
  const newEmpPayload = {
    name: 'Vikramaditya S',
    employeeId: 'GTS-FIELD-101',
    designation: 'Operations Executive',
    band: 'B1',
    department: 'Facility Operations',
    region: 'Karnataka',
    location: 'Bengaluru Tech Park Site',
    mobile: '9845012345',
    email: 'vikram.s@gtsfacilities.com',
    reportingManager: 'Samuel',
    approvingAuthorityId: 'u-samuel',
    approvingAuthorityName: 'Samuel',
    password: 'VikramPassword@2026'
  };

  res = await fetch(`${BASE}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(newEmpPayload)
  });
  data = await res.json();
  const newEmp = data.user;
  console.log(`5. Generated New Employee: "${newEmp.name}" (ID: ${newEmp.employeeId}, Band: ${newEmp.band}, Status: ${newEmp.status})`);
  if (!res.ok || newEmp.status !== 'ACTIVE') throw new Error('Employee generation failed');

  // Test 6: Sign in using Newly Generated Employee Name & Custom Password
  res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'Vikramaditya S', password: 'VikramPassword@2026' })
  });
  data = await res.json();
  console.log(`6. Employee Sign In by Name: OK (Logged in as ${data.user?.name})`);
  if (!res.ok) throw new Error('Login with new employee failed');

  // Test 7: New Employee creates a Tour
  res = await fetch(`${BASE}/api/tours`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-user-id': newEmp.id },
    body: JSON.stringify({
      purpose: 'Client Audit & Site Onboarding',
      clientOrSite: 'Apex Technology Campus Phase 3',
      startLocation: 'Bengaluru',
      destination: 'Hubballi Site',
      startDate: '2026-10-10',
      endDate: '2026-10-12',
      travelMode: 'Train',
      remarks: 'Quarterly facility audit'
    })
  });
  data = await res.json();
  const createdTour = data.tour;
  console.log(`7. Created Tour for New Employee: ${createdTour.id} (${createdTour.numberOfDays} Days)`);

  // Test 8: Create Draft Expense Claim for Tour
  res = await fetch(`${BASE}/api/claims/draft`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-user-id': newEmp.id },
    body: JSON.stringify({ tourId: createdTour.id })
  });
  data = await res.json();
  const draftClaim = data.claim;
  console.log(`8. Generated Draft Claim: ${draftClaim.id}`);

  // Test 9: Add Expense Items (Train + Hotel within policy limit)
  res = await fetch(`${BASE}/api/claims/${draftClaim.id}/items`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-user-id': newEmp.id },
    body: JSON.stringify({
      category: 'TRAVEL',
      date: '2026-10-10',
      amount: 850,
      fromLocation: 'Bengaluru',
      toLocation: 'Hubballi',
      travelMode: 'Train',
      ticketNo: 'IRCTC-PNR-889922'
    })
  });
  data = await res.json();

  res = await fetch(`${BASE}/api/claims/${draftClaim.id}/items`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-user-id': newEmp.id },
    body: JSON.stringify({
      category: 'HOTEL',
      date: '2026-10-10',
      amount: 1400, // Within B1 ₹1500 cap
      hotelName: 'Hotel President Hubballi',
      hotelCity: 'Hubballi',
      nights: 1,
      hotelInvoiceNo: 'INV-HBL-102'
    })
  });
  data = await res.json();
  console.log(`9. Added Expenses: Gross Claim = Rs. ${data.claim?.grossClaim}`);

  // Test 10: Submit Claim for Regional Approval
  res = await fetch(`${BASE}/api/claims/${draftClaim.id}/submit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-user-id': newEmp.id },
    body: JSON.stringify({ declarationConfirmed: true })
  });
  data = await res.json();
  console.log(`10. Claim Submitted: Status is now "${data.claim?.status}"`);
  if (data.claim?.status !== 'PENDING_REGIONAL_APPROVAL') throw new Error('Expected status PENDING_REGIONAL_APPROVAL');

  // Test 11: Regional Approver (Samuel) Approves Claim
  res = await fetch(`${BASE}/api/claims/${draftClaim.id}/regional-action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-user-id': 'u-samuel' },
    body: JSON.stringify({ action: 'APPROVE', comments: 'All bills verified within B1 entitlement.' })
  });
  data = await res.json();
  console.log(`11. Regional Approver (Samuel) Approved: Status is now "${data.claim?.status}"`);
  if (data.claim?.status !== 'PENDING_PRESIDENT_APPROVAL') throw new Error('Expected status PENDING_PRESIDENT_APPROVAL');

  // Test 12: President (Bharanidhar Tarimana) Approves Claim
  res = await fetch(`${BASE}/api/claims/${draftClaim.id}/president-action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-user-id': 'u-president' },
    body: JSON.stringify({ action: 'APPROVE', comments: 'Final management approval granted.' })
  });
  data = await res.json();
  console.log(`12. President (Bharanidhar Tarimana) Approved: Status is now "${data.claim?.status}"`);
  if (data.claim?.status !== 'PENDING_AUDIT') throw new Error('Expected status PENDING_AUDIT');

  // Test 13: Auditor completes 13-point audit
  res = await fetch(`${BASE}/api/claims/${draftClaim.id}/audit-action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-user-id': 'u-auditor' },
    body: JSON.stringify({
      action: 'PASS',
      auditorComments: 'All 13 checklist points verified. Ready for payment disbursal.',
      checklist: {
        emp_verified: 'PASS',
        total_calc_verified: 'PASS'
      }
    })
  });
  data = await res.json();
  console.log(`13. Internal Audit Verified: Status is now "${data.claim?.status}"`);
  if (data.claim?.status !== 'PENDING_ACCOUNTS') throw new Error('Expected status PENDING_ACCOUNTS');

  // Test 14: Accounts processes payment
  res = await fetch(`${BASE}/api/claims/${draftClaim.id}/accounts-action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-user-id': 'u-accounts' },
    body: JSON.stringify({
      action: 'PAYMENT_PROCESSED',
      paymentReference: 'HDFC-NEFT-20261010-998811',
      paymentDate: '2026-10-10',
      processedAmount: data.claim?.grossClaim,
      remarks: 'Payment settled to registered salary account.'
    })
  });
  data = await res.json();
  console.log(`14. Accounts Disbursed Payment: Status is now "${data.claim?.status}" (Payment Ref: ${data.claim?.paymentReference})`);
  if (data.claim?.status !== 'CLOSED') throw new Error('Expected status CLOSED');

  // Now, to leave the database in the exact clean state requested by the user, clear the test claim and test tour
  console.log('\n--- RESETTING DATABASE TO COMPLETELY EMPTY STATE (0 CLAIMS, 0 TOURS, 0 DUMMY USERS) ---');
  const fs = await import('fs');
  const path = await import('path');
  const dbPath = path.join(process.cwd(), 'server', 'data', 'db.json');
  const currentDb = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
  currentDb.claims = [];
  currentDb.tours = [];
  currentDb.expenseItems = [];
  currentDb.documents = [];
  currentDb.auditTrail = [];
  currentDb.notifications = [];
  currentDb.users = currentDb.users.filter((u: any) => u.id !== newEmp.id);
  fs.writeFileSync(dbPath, JSON.stringify(currentDb, null, 2), 'utf-8');

  console.log('>>> ALL 14 TESTS PASSED! Clean state restored for production use. <<<');
}

verifyCleanStateAndOpenGeneration().catch(err => {
  console.error('VERIFICATION ERROR:', err);
  process.exit(1);
});
