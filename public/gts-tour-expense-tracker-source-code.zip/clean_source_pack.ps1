$exclude = @('node_modules', 'dist', '.git', '*.zip', '*.log', 'temp_*')
$items = Get-ChildItem -Path . | Where-Object { 
    $name = $_.Name
    $skip = $false
    foreach ($pat in $exclude) {
        if ($name -like $pat) { $skip = $true; break }
    }
    -not $skip
} | Select-Object -ExpandProperty FullName

$destZip = Join-Path (Get-Location) 'gts-tour-expense-tracker-source-code.zip'
if (Test-Path $destZip) { Remove-Item $destZip -Force }

Compress-Archive -Path $items -DestinationPath $destZip -Force

Copy-Item $destZip 'dist\gts-tour-expense-tracker-source-code.zip' -Force
Copy-Item $destZip 'public\gts-tour-expense-tracker-source-code.zip' -Force

$len = (Get-Item $destZip).Length / 1MB
Write-Host "Success! Created clean source code zip ($([Math]::Round($len, 2)) MB)"
