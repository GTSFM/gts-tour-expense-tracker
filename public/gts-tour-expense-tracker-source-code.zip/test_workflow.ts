import { store } from './server/store.js';

console.log('====================================================');
console.log('RUNNING GTS TOUR EXPENSE TRACKER VERIFICATION TESTS');
console.log('====================================================');

let passedTests = 0;
let totalTests = 0;

function assert(condition: boolean, testName: string) {
  totalTests++;
  if (condition) {
    console.log(`[PASS] ${testName}`);
    passedTests++;
  } else {
    console.error(`[FAIL] ${testName}`);
    process.exitCode = 1;
  }
}

// TEST 1: Seed Users & Roles
const users = store.getUsers();
assert(users.length >= 12, 'Test 1: Pre-seeded users exist (count >= 12)');

const emp1 = store.getUserById('u-emp-1');
assert(
  emp1?.name === 'Operations Executive / Manager' && emp1?.band === 'B1' && emp1?.password === 'GTSOPS@123',
  'Test 2: Operations Executive / Manager is B1 Employee with password GTSOPS@123'
);

const dir1 = store.getUserById('u-dir-1');
const dir2 = store.getUserById('u-dir-2');
assert(
  dir1?.role === 'DIRECTOR' && !dir1?.band && dir1?.password === 'Mariappan@123',
  'Test 2B: Director 1 (Mariappan S) has no Band and password Mariappan@123'
);
assert(
  dir2?.role === 'DIRECTOR' && !dir2?.band && dir2?.password === 'Prabakar@123',
  'Test 2C: Director 2 (Prabakar B) has no Band and password Prabakar@123'
);

const krishnan = store.getUserById('u-krishnan');
assert(
  krishnan?.assignedTerritories?.includes('Telangana') && krishnan?.assignedTerritories?.includes('Andhra Pradesh') && krishnan?.password === 'GTSPCH@01',
  'Test 3: Krishnan Govindan territory is AP & Telangana with PW GTSPCH@01'
);

const samuel = store.getUserById('u-samuel');
assert(
  samuel?.assignedTerritories?.includes('Karnataka') && samuel?.assignedTerritories?.includes('East') && samuel?.password === 'GTSPCH@02',
  'Test 4: Samuel territory is Karnataka & East with PW GTSPCH@02'
);

const president = store.getUserById('u-president');
assert(
  president?.name === 'Bharanidhar Tarimana' && president?.role === 'PRESIDENT' && president?.password === 'Bharani@123',
  'Test 5: President is Bharanidhar Tarimana with PW Bharani@123'
);

// TEST 6: Employee Registration & Validation Status
const testEmpId = `GTS-TST-${Date.now()}`;
const newEmp = store.createUser({
  employeeId: testEmpId,
  name: 'Test Field Executive',
  designation: 'Operations Executive',
  band: 'B1',
  department: 'Facility Operations',
  region: 'Telangana',
  location: 'Warangal Site',
  mobile: '9849123456',
  email: `testexec-${Date.now()}@gts.com`,
  role: 'EMPLOYEE',
  reportingManager: 'Krishnan Govindan',
  approvingAuthorityId: 'u-krishnan',
  approvingAuthorityName: 'Krishnan Govindan',
  status: 'PENDING_VALIDATION'
});
assert(newEmp.status === 'PENDING_VALIDATION', 'Test 6: New registration has status PENDING_VALIDATION');

// Duplicate employee ID rejection
let duplicateCaught = false;
try {
  store.createUser({
    employeeId: testEmpId,
    name: 'Duplicate Guy',
    designation: 'Operations Executive',
    band: 'B1',
    department: 'Facility Operations',
    region: 'Telangana',
    location: 'Warangal Site',
    mobile: '9849123456',
    email: 'dup@gts.com',
    role: 'EMPLOYEE',
    reportingManager: 'Krishnan Govindan',
    approvingAuthorityId: 'u-krishnan',
    approvingAuthorityName: 'Krishnan Govindan',
    status: 'PENDING_VALIDATION'
  });
} catch (e: any) {
  duplicateCaught = true;
}
assert(duplicateCaught, 'Test 7: Duplicate Employee ID is prevented');

// Validate Employee
const validatedEmp = store.validateEmployee(newEmp.id, krishnan!);
assert(validatedEmp.status === 'ACTIVE', 'Test 8: Validated employee becomes ACTIVE');

// TEST 9: Tour Creation
const tour = store.createTour(
  {
    employeeId: validatedEmp.employeeId,
    userId: validatedEmp.id,
    employeeName: validatedEmp.name,
    designation: validatedEmp.designation,
    band: validatedEmp.band,
    department: validatedEmp.department,
    region: validatedEmp.region,
    approvingAuthorityName: validatedEmp.approvingAuthorityName,
    purpose: 'Site Mobilization & Staff Training',
    clientOrSite: 'Pharma SEZ Site 1',
    startLocation: 'Hyderabad',
    destination: 'Warangal',
    startDate: '2026-10-01',
    endDate: '2026-10-03',
    numberOfDays: 3,
    travelMode: 'Bus',
    priorApprovalRequired: false
  },
  validatedEmp
);
assert(tour.id.startsWith('GTS-TRV-') && tour.numberOfDays === 3, 'Test 9: Tour created with auto Tour ID and 3 days');

// TEST 10: Claim Draft Creation
const draftClaim = store.createDraftClaim(tour.id, validatedEmp);
assert(draftClaim.id.startsWith('GTS-CLM-') && draftClaim.status === 'DRAFT', 'Test 10: Draft claim created');

// TEST 11: Expense Limits & Policy Calculations for B1
// B1 Food: Breakfast ₹100 max. Entering ₹80 (within limit)
const foodItem1 = store.addExpenseItem(
  {
    claimId: draftClaim.id,
    tourId: tour.id,
    category: 'FOOD',
    date: '2026-10-01',
    amount: 80,
    mealType: 'Breakfast',
    restaurantVendor: 'Highway Diner',
    foodBillNo: 'BILL-001',
    policyLimit: 100,
    claimedAmount: 80,
    isException: false,
    excessAmount: 0,
    eligibleAmount: 80
  },
  validatedEmp
);
assert(foodItem1.isException === false && foodItem1.eligibleAmount === 80, 'Test 11: Food item within limit (₹80 <= ₹100)');

// B1 Food: Breakfast ₹130 (Exceeds limit by ₹30)
const foodItem2 = store.addExpenseItem(
  {
    claimId: draftClaim.id,
    tourId: tour.id,
    category: 'FOOD',
    date: '2026-10-02',
    amount: 130,
    mealType: 'Breakfast',
    restaurantVendor: 'Station Hotel',
    foodBillNo: 'BILL-002',
    policyLimit: 100,
    claimedAmount: 130,
    isException: false,
    excessAmount: 0,
    eligibleAmount: 130
  },
  validatedEmp
);
assert(
  foodItem2.isException === true && foodItem2.excessAmount === 30 && foodItem2.eligibleAmount === 100,
  'Test 12: Food item exceeds limit flagged as Exception (Policy: 100, Claimed: 130, Excess: 30)'
);

// B1 Hotel: ₹1,800/night (Exceeds B1 cap of ₹1,500/night by ₹300)
const hotelItem = store.addExpenseItem(
  {
    claimId: draftClaim.id,
    tourId: tour.id,
    category: 'HOTEL',
    date: '2026-10-01',
    amount: 1800,
    hotelName: 'Grand Residency Warangal',
    hotelCity: 'Warangal',
    checkIn: '2026-10-01',
    checkOut: '2026-10-02',
    nights: 1,
    roomAmount: 1600,
    gst: 200,
    hotelInvoiceNo: 'INV-GR-881',
    policyLimit: 1500,
    claimedAmount: 1800,
    isException: false,
    excessAmount: 0,
    eligibleAmount: 1800,
    exceptionReason: 'Only deluxe room was available near client site'
  },
  validatedEmp
);
assert(
  hotelItem.isException === true && hotelItem.excessAmount === 300,
  'Test 13: Hotel item exceeds B1 ₹1,500 cap, marked Exception (Excess: 300)'
);

// Claim recalculation
const recomputedClaim = store.getClaimById(draftClaim.id);
assert(
  recomputedClaim?.grossClaim === 80 + 130 + 1800 &&
    recomputedClaim?.exceptionAmount === 330 &&
    recomputedClaim?.policyEligible === 80 + 100 + 1500,
  'Test 14: Automatic financial calculations (Gross: ₹2,010, Exception: ₹330, Policy Eligible: ₹1,680)'
);

// Duplicate detection check
const dupCheck = store.checkForDuplicates(draftClaim.id);
assert(dupCheck.isDuplicate === false, 'Test 15: No duplicates in initial claim items');

// TEST 16: Territory Isolation
const krishnanClaims = store.getClaimsForApprover(krishnan!);
const samuelClaims = store.getClaimsForApprover(samuel!);
assert(
  krishnanClaims.every(c => ['Andhra Pradesh', 'Telangana'].includes(c.region)),
  'Test 16: Krishnan Govindan only sees claims from AP & Telangana'
);
assert(
  samuelClaims.every(c => ['Karnataka', 'East'].includes(c.region)),
  'Test 17: Samuel only sees claims from Karnataka & East'
);

// TEST 18: Normal Employee Workflow Submit
const submittedClaim = store.submitClaim(draftClaim.id, true, validatedEmp);
assert(submittedClaim.status === 'PENDING_REGIONAL_APPROVAL', 'Test 18: Normal employee claim moves to PENDING_REGIONAL_APPROVAL');

// TEST 19: Profit Centre Head Routing
// Create tour and claim for Profit Centre Head (Tejinder)
const tejinder = store.getUserById('u-tejinder')!;
const pchTour = store.createTour(
  {
    employeeId: tejinder.employeeId,
    userId: tejinder.id,
    employeeName: tejinder.name,
    designation: tejinder.designation,
    band: tejinder.band,
    department: tejinder.department,
    region: tejinder.region,
    approvingAuthorityName: 'Bharanidhar Tarimana',
    purpose: 'Quarterly Executive Review',
    clientOrSite: 'HQ Bangalore',
    startLocation: 'Bangalore',
    destination: 'Mysore',
    startDate: '2026-10-05',
    endDate: '2026-10-06',
    numberOfDays: 2,
    travelMode: 'Train',
    priorApprovalRequired: false
  },
  tejinder
);
const pchClaim = store.createDraftClaim(pchTour.id, tejinder);
store.addExpenseItem(
  {
    claimId: pchClaim.id,
    tourId: pchTour.id,
    category: 'TRAVEL',
    date: '2026-10-05',
    amount: 900,
    travelMode: 'Train',
    ticketNo: 'PNR-PCH-990',
    policyLimit: 1500,
    claimedAmount: 900,
    isException: false,
    excessAmount: 0,
    eligibleAmount: 900
  },
  tejinder
);
const pchSubmitted = store.submitClaim(pchClaim.id, true, tejinder);
assert(
  pchSubmitted.status === 'PENDING_PRESIDENT_APPROVAL',
  'Test 19: Profit Centre Head claim BYPASSES regional approver directly to Bharanidhar Tarimana (President)'
);

// TEST 20: Regional Approver cannot approve own claim (Rule 1)
let rule1Caught = false;
try {
  store.regionalAction(pchSubmitted.id, 'APPROVE', 'Trying to approve own claim', tejinder);
} catch (e) {
  rule1Caught = true;
}
assert(rule1Caught, 'Test 20: Approver cannot approve own claim');

// TEST 21: Regional Approval by Krishnan
const regApproved = store.regionalAction(
  submittedClaim.id,
  'APPROVE',
  'Approved with hotel exception noted for Warangal client site.',
  krishnan!
);
assert(
  regApproved.status === 'PENDING_PRESIDENT_APPROVAL',
  'Test 21: Regional approval moves claim to PENDING_PRESIDENT_APPROVAL'
);

// TEST 22: President Approval
const presApproved = store.presidentAction(
  regApproved.id,
  'APPROVE',
  'Management approval granted. Forwarded to Audit.',
  president!
);
assert(presApproved.status === 'PENDING_AUDIT', 'Test 22: President approval moves claim to PENDING_AUDIT');

// TEST 23: 13-Point Audit Module
const auditor = store.getUserById('u-auditor')!;
const checklistResult: Record<string, { status: 'PASS' | 'FAIL' | 'NA'; comment?: string }> = {
  emp_verified: { status: 'PASS' },
  emp_id_verified: { status: 'PASS' },
  tour_dates_verified: { status: 'PASS' },
  travel_docs_verified: { status: 'PASS' },
  food_bills_verified: { status: 'PASS' },
  local_travel_docs_verified: { status: 'PASS' },
  hotel_invoice_verified: { status: 'PASS' },
  other_expenses_verified: { status: 'PASS' },
  policy_limits_verified: { status: 'PASS' },
  exception_approvals_verified: { status: 'PASS' },
  duplicate_bills_checked: { status: 'PASS' },
  documents_readable: { status: 'PASS' },
  total_calc_verified: { status: 'PASS' }
};

const auditPassed = store.auditAction(
  presApproved.id,
  'PASS',
  checklistResult,
  'All 13 checklist points verified. Supporting documents clear and match totals.',
  auditor
);
assert(
  auditPassed.status === 'PENDING_ACCOUNTS' && auditPassed.auditStatus === 'PASSED',
  'Test 23: 13-point Audit PASS moves claim to PENDING_ACCOUNTS'
);

// TEST 24: Accounts Payment Processing
const accounts = store.getUserById('u-accounts')!;
const closedClaim = store.accountsAction(
  auditPassed.id,
  'PAYMENT_PROCESSED',
  {
    paymentReference: 'HDFC-NEFT-20261004-881920',
    paymentDate: '2026-10-04',
    processedAmount: auditPassed.grossClaim,
    remarks: 'Disbursed to employee registered bank account.'
  },
  accounts
);
assert(
  closedClaim.status === 'CLOSED' && closedClaim.paymentStatus === 'PROCESSED',
  'Test 24: Accounts payment marks claim PAYMENT_PROCESSED and CLOSED'
);

// TEST 25: Audit Trail Integrity
const claimAuditTrail = store.getAuditTrail(draftClaim.id);
assert(claimAuditTrail.length >= 6, 'Test 25: Full immutable audit trail captured with timestamps & users');

// TEST 26: User Lookup by Alias / ID
const userByAlias = store.findUserByIdentifier('RH 01 - GTSPCH');
assert(userByAlias?.employeeId === 'GTS-RH-01', 'Test 26: User lookup by alias (RH 01 - GTSPCH) succeeds');

// TEST 27: Password Change Provision
const passChange = store.changePassword('u-emp-1', 'GTSOPS@123', 'GTSOPS@New999');
assert(passChange.success && store.getUserById('u-emp-1')?.password === 'GTSOPS@New999', 'Test 27: Password change provision works');
// Reset back
store.changePassword('u-emp-1', 'GTSOPS@New999', 'GTSOPS@123');

console.log('====================================================');
console.log(`TEST SUMMARY: ${passedTests}/${totalTests} TESTS PASSED!`);
console.log('====================================================');
