Add-Type -AssemblyName System.Drawing

$logoPath = (Resolve-Path "public/logo.jpg").Path
$srcImg = [System.Drawing.Bitmap]::FromFile($logoPath)

Write-Output "Image size: $($srcImg.Width) x $($srcImg.Height)"

# Check edges for any non-purple pixels
$bgR = 60
$bgG = 42
$bgB = 154

# Clean cropped version
$cropLeft = 2
$cropRight = 2
$cropTop = 2
$cropBottom = 2

$cropWidth = $srcImg.Width - ($cropLeft + $cropRight)
$cropHeight = $srcImg.Height - ($cropTop + $cropBottom)

$croppedBmp = New-Object System.Drawing.Bitmap($cropWidth, $cropHeight, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$gCrop = [System.Drawing.Graphics]::FromImage($croppedBmp)
$gCrop.DrawImage($srcImg, 
    (New-Object System.Drawing.Rectangle(0, 0, $cropWidth, $cropHeight)),
    $cropLeft, $cropTop, $cropWidth, $cropHeight,
    [System.Drawing.GraphicsUnit]::Pixel)
$gCrop.Dispose()
$srcImg.Dispose()

# Save cleaned logo
$croppedBmp.Save("public/logo-clean.png", [System.Drawing.Imaging.ImageFormat]::Png)
Write-Output "Saved clean logo: public/logo-clean.png ($cropWidth x $cropHeight)"

function Generate-Icon {
    param (
        [int]$Size,
        [string]$Path,
        [double]$PaddingPercent
    )

    $iconBmp = New-Object System.Drawing.Bitmap($Size, $Size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($iconBmp)

    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality

    # Seamless background fill using exact sampled logo color
    $brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, $bgR, $bgG, $bgB))
    $g.FillRectangle($brush, 0, 0, $Size, $Size)

    $maxDrawWidth = $Size * (1.0 - ($PaddingPercent * 2.0))
    $maxDrawHeight = $Size * (1.0 - ($PaddingPercent * 2.0))

    $scale = [Math]::Min($maxDrawWidth / $cropWidth, $maxDrawHeight / $cropHeight)
    $targetW = [int]($cropWidth * $scale)
    $targetH = [int]($cropHeight * $scale)

    $targetX = [int](($Size - $targetW) / 2)
    $targetY = [int](($Size - $targetH) / 2)

    $destRect = New-Object System.Drawing.Rectangle($targetX, $targetY, $targetW, $targetH)
    $g.DrawImage($croppedBmp, $destRect, 0, 0, $cropWidth, $cropHeight, [System.Drawing.GraphicsUnit]::Pixel)

    $iconBmp.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)

    $g.Dispose()
    $brush.Dispose()
    $iconBmp.Dispose()
    Write-Output "Generated icon: $Path ($Size x $Size)"
}

# Standard Android & Web icon (safe padding)
Generate-Icon -Size 512 -Path "public/icon-512.png" -PaddingPercent 0.14
# Maskable Android icon (Android circle/squircle safe zone is 80% circle, so ~22% padding ensures no clipping)
Generate-Icon -Size 512 -Path "public/icon-maskable-512.png" -PaddingPercent 0.22
# 192x192 icon for standard PWA
Generate-Icon -Size 192 -Path "public/icon-192.png" -PaddingPercent 0.14
# 180x180 Apple touch icon for iOS home screen
Generate-Icon -Size 180 -Path "public/apple-touch-icon.png" -PaddingPercent 0.14
# Favicons
Generate-Icon -Size 64 -Path "public/favicon-64.png" -PaddingPercent 0.10
Generate-Icon -Size 32 -Path "public/favicon-32.png" -PaddingPercent 0.08

$croppedBmp.Dispose()
Write-Output "All icons successfully created!"
